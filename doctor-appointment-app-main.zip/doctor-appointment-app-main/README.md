# Medikkare

Medikkare is a doctor appointment app. Written in Flutter. Inspired by Dribbble.

![base-image](https://cdn.dribbble.com/users/2492254/screenshots/16622245/media/395dbb07798a3958a972898d1e91b504.png?compress=1&resize=800x600&vertical=top)

## Demo
![demo-image](https://i.imgur.com/wnPW0HJ.gif)

## Design
- [Inspired by Dribbble](https://dribbble.com/shots/16622245-Medicare-Doctor-Appointment-App)

## License
MIT
